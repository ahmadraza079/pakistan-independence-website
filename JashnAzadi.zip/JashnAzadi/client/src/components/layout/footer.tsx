import { Link } from "wouter";
import { Moon, Star, Facebook, Twitter, Instagram } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-[#01411C] text-white py-12">
      <div className="container mx-auto px-4 text-center">
        <div className="mb-8">
          <div className="flex justify-center items-center mb-4">
            <Moon className="text-[#FFD700] h-6 w-6 mr-2 transform -rotate-45" />
            <Star className="text-[#FFD700] h-5 w-5" />
          </div>
          <h3 className="text-2xl font-bold mb-2">Pakistan Zindabad!</h3>
          <p className="text-white opacity-80">Long Live Pakistan</p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <div className="space-y-2">
              <Link href="/" className="block hover:text-[#FFD700] transition-colors">Home</Link>
              <Link href="/heroes" className="block hover:text-[#FFD700] transition-colors">Heroes</Link>
              <Link href="/places" className="block hover:text-[#FFD700] transition-colors">Places</Link>
            </div>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Learn More</h4>
            <div className="space-y-2">
              <Link href="/history" className="block hover:text-[#FFD700] transition-colors">History</Link>
              <Link href="/contact" className="block hover:text-[#FFD700] transition-colors">Contact</Link>
            </div>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Connect</h4>
            <div className="flex justify-center space-x-4">
              <a href="#" className="text-white hover:text-[#FFD700] transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-white hover:text-[#FFD700] transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-white hover:text-[#FFD700] transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-white border-opacity-20 pt-8">
          <p className="text-white opacity-70">
            © 2024 Pakistan Independence Day Celebration. Made with 💚 for Pakistan.
          </p>
        </div>
      </div>
    </footer>
  );
}
