import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu, Flag, Moon, Star } from "lucide-react";

const navItems = [
  { href: "/", label: "Home" },
  { href: "/heroes", label: "Heroes" },
  { href: "/places", label: "Places" },
  { href: "/history", label: "History" },
  { href: "/contact", label: "Contact" },
];

export default function Navigation() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="bg-[#01411C] shadow-lg fixed w-full top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <Link href="/" className="flex items-center text-white hover:text-[#FFD700] transition-colors duration-300">
            <Flag className="h-6 w-6 mr-2" />
            <span className="font-bold text-xl">Pakistan Independence Day</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`transition-colors duration-300 ${
                  location === item.href
                    ? "text-[#FFD700] font-semibold"
                    : "text-white hover:text-[#FFD700]"
                }`}
              >
                {item.label}
              </Link>
            ))}
          </div>

          {/* Mobile Navigation */}
          <div className="md:hidden flex items-center">
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="text-white hover:text-[#FFD700]">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="bg-[#01411C] border-[#FFD700]">
                <div className="flex flex-col space-y-4 mt-8">
                  <div className="flex items-center justify-center mb-6 text-[#FFD700]">
                    <Moon className="h-6 w-6 mr-2 transform -rotate-45" />
                    <Star className="h-5 w-5" />
                  </div>
                  {navItems.map((item) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      onClick={() => setIsOpen(false)}
                      className={`block text-center py-3 px-4 rounded-lg transition-colors duration-300 ${
                        location === item.href
                          ? "text-[#FFD700] bg-white bg-opacity-10 font-semibold"
                          : "text-white hover:text-[#FFD700] hover:bg-white hover:bg-opacity-5"
                      }`}
                    >
                      {item.label}
                    </Link>
                  ))}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
}
