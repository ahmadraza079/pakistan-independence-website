import { Card, CardContent } from "@/components/ui/card";

interface PlaceCardProps {
  name: string;
  imageUrl: string;
  description: string;
}

export default function PlaceCard({ name, imageUrl, description }: PlaceCardProps) {
  return (
    <Card className="bg-white rounded-xl shadow-lg overflow-hidden transform hover:scale-105 transition-all duration-300">
      <img 
        src={imageUrl} 
        alt={name} 
        className="w-full h-64 object-cover"
      />
      <CardContent className="p-6">
        <h3 className="text-2xl font-bold text-[#01411C] mb-3">{name}</h3>
        <p className="text-gray-600 leading-relaxed">{description}</p>
      </CardContent>
    </Card>
  );
}
