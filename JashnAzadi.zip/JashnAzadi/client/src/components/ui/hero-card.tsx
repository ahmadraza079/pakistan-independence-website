import { Card, CardContent } from "@/components/ui/card";

interface HeroCardProps {
  name: string;
  title: string;
  imageUrl: string;
  contribution: string;
  description: string;
}

export default function HeroCard({ name, title, imageUrl, contribution, description }: HeroCardProps) {
  return (
    <div className="hero-card group relative bg-white rounded-xl shadow-lg overflow-hidden transform hover:scale-105 transition-all duration-300">
      <img 
        src={imageUrl} 
        alt={name} 
        className="w-full h-80 object-cover"
      />
      <div className="p-6">
        <h3 className="text-xl font-bold text-[#01411C] mb-2">{name}</h3>
        <p className="text-gray-600 text-sm">{title}</p>
      </div>
      <div className="hero-overlay absolute inset-0 bg-[#01411C] bg-opacity-95 p-6 flex flex-col justify-center text-white">
        <h3 className="text-xl font-bold mb-4">{contribution}</h3>
        <p className="text-sm leading-relaxed">{description}</p>
      </div>
    </div>
  );
}
