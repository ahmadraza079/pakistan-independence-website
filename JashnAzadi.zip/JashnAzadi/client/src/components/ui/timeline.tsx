import { Card, CardContent } from "@/components/ui/card";

interface TimelineItem {
  year: string;
  title: string;
  description: string;
}

interface TimelineProps {
  items: TimelineItem[];
}

export default function Timeline({ items }: TimelineProps) {
  return (
    <div className="max-w-6xl mx-auto">
      <div className="relative">
        {/* Timeline Line */}
        <div className="absolute left-1/2 transform -translate-x-px h-full w-0.5 bg-[#01411C]"></div>
        
        {/* Timeline Items */}
        <div className="space-y-12">
          {items.map((item, index) => (
            <div key={index} className="relative flex items-center">
              <Card className={`flex-1 shadow-lg ${index % 2 === 0 ? 'mr-8' : 'ml-8'}`}>
                <CardContent className="p-6">
                  <div className={`flex items-center mb-4 ${index % 2 === 1 ? 'justify-end' : ''}`}>
                    <div className={`w-4 h-4 bg-[#FFD700] rounded-full ${index % 2 === 1 ? 'ml-4' : 'mr-4'}`}></div>
                    <span className="text-2xl font-bold text-[#01411C]">{item.year}</span>
                  </div>
                  <h3 className={`text-xl font-semibold mb-2 ${index % 2 === 1 ? 'text-right' : ''}`}>
                    {item.title}
                  </h3>
                  <p className={`text-gray-600 ${index % 2 === 1 ? 'text-right' : ''}`}>
                    {item.description}
                  </p>
                </CardContent>
              </Card>
              <div className="absolute left-1/2 transform -translate-x-1/2 w-4 h-4 bg-[#01411C] rounded-full border-4 border-white"></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
