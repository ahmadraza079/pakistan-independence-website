import HeroCard from "@/components/ui/hero-card";

const heroes = [
  {
    name: "Muhammad Ali Jinnah",
    title: "Quaid-e-Azam (Great Leader)",
    imageUrl: "https://www.youlinmagazine.com/articles/1635-1.jpg",
    contribution: "Quaid-e-Azam",
    description: "Founder of Pakistan, led the All-India Muslim League and championed the two-nation theory that resulted in the creation of Pakistan."
  },
  {
    name: "Allama Iqbal",
    title: "Poet-Philosopher",
    imageUrl: "https://upload.wikimedia.org/wikipedia/commons/d/d9/Allama_muhammad_iqbal.jpg",
    contribution: "Allama Iqbal",
    description: "National poet and philosopher who conceived the idea of Pakistan. His poetry inspired the Pakistan movement."
  },
  {
    name: "Fatima Jinnah",
    title: "Madar-e-Millat",
    imageUrl: "https://photos.hamariweb.com/photos/Political-Mohtarma-Fatima-Jinnah--Mader-e-Millat-5415.jpg",
    contribution: "Madar-e-Millat",
    description: "Mother of the Nation, dental surgeon, biographer, and close confidant of Muhammad Ali Jinnah."
  },
  {
    name: "Liaquat Ali Khan",
    title: "First Prime Minister",
    imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/88/Liaquat_Ali_Khan_1945.jpg/640px-Liaquat_Ali_Khan_1945.jpg",
    contribution: "Quaid-e-Millat",
    description: "First Prime Minister of Pakistan, played a crucial role in the establishment and early development of Pakistan."
  },
  {
    name: "Dr. A.Q. Khan",
    title: "Nuclear Scientist",
    imageUrl: "https://image.tmdb.org/t/p/w500/aPcabZHS3Fqdb9D5FrVootdnKXm.jpg",
    contribution: "Father of Nuclear Program",
    description: "Renowned metallurgist and nuclear engineer who founded Pakistan's nuclear weapons program."
  }
];

export default function Heroes() {
  return (
    <div className="pt-16">
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-[#01411C] mb-4">
              National Heroes
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Honoring the visionaries who shaped our nation's destiny
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-8">
            {heroes.map((hero, index) => (
              <HeroCard
                key={index}
                name={hero.name}
                title={hero.title}
                imageUrl={hero.imageUrl}
                contribution={hero.contribution}
                description={hero.description}
              />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
