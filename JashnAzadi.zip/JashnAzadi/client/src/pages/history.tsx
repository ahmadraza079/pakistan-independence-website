import Timeline from "@/components/ui/timeline";
import { Card, CardContent } from "@/components/ui/card";

const timelineItems = [
  {
    year: "1857",
    title: "War of Independence",
    description: "The first major uprising against British colonial rule, laying the foundation for future independence movements."
  },
  {
    year: "1930",
    title: "Allama Iqbal's Vision",
    description: "Presidential address proposing the creation of a separate Muslim state in the Indian subcontinent."
  },
  {
    year: "1940",
    title: "Lahore Resolution",
    description: "The historic resolution demanding the creation of independent states for Muslims in South Asia."
  },
  {
    year: "1947",
    title: "Independence Day",
    description: "Pakistan emerged as an independent nation on August 14, 1947, fulfilling the dream of millions."
  }
];

const nationalSymbols = [
  {
    icon: "🌙",
    title: "Crescent & Star",
    description: "Symbols of progress and light, representing the aspirations of our nation."
  },
  {
    icon: "🦌",
    title: "Markhor",
    description: "National animal symbolizing strength, dignity, and the mountainous heritage of Pakistan."
  },
  {
    icon: "🌺",
    title: "Jasmine",
    description: "National flower representing purity, grace, and the natural beauty of our homeland."
  }
];

export default function History() {
  return (
    <div className="pt-16">
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-[#01411C] mb-4">
              Our Heritage
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              The journey of Pakistan: From vision to reality
            </p>
          </div>
          
          <Timeline items={timelineItems} />

          {/* National Symbols */}
          <div className="mt-20">
            <h2 className="text-3xl font-bold text-center text-[#01411C] mb-12">National Symbols</h2>
            <div className="grid md:grid-cols-3 gap-8">
              {nationalSymbols.map((symbol, index) => (
                <Card key={index} className="text-center shadow-lg">
                  <CardContent className="p-8">
                    <div className="text-6xl mb-4">{symbol.icon}</div>
                    <h3 className="text-xl font-semibold mb-2">{symbol.title}</h3>
                    <p className="text-gray-600">{symbol.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
