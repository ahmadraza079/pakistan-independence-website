import PlaceCard from "@/components/ui/place-card";

import hunzaValleyImg from "@assets/hunza valley_1754478188735.jpeg";
import badshahiMosqueImg from "@assets/badshahi mosque_1754478188734.jpeg";
import minarPakistanImg from "@assets/Minar e pakistan_1754478188737.jpeg";
import mazarQuaidImg from "@assets/mazar e quaid_1754478188736.jpeg";
import swatValleyImg from "@assets/swat valley_1754478188738.jpeg";

const places = [
  {
    name: "Hunza Valley",
    imageUrl: hunzaValleyImg,
    description: "A breathtaking mountainous valley known for its stunning landscapes, apricot blossoms, and the majestic Karakoram mountain range."
  },
  {
    name: "Badshahi Mosque",
    imageUrl: badshahiMosqueImg,
    description: "A magnificent Mughal-era mosque in Lahore, renowned for its grand architecture and historical significance as one of the largest mosques in the world."
  },
  {
    name: "Minar-e-Pakistan",
    imageUrl: minarPakistanImg,
    description: "A towering monument in Lahore commemorating the Lahore Resolution of 1940, symbolizing the struggle for Pakistani independence."
  },
  {
    name: "Mazar-e-Quaid",
    imageUrl: mazarQuaidImg,
    description: "The mausoleum of Muhammad Ali Jinnah in Karachi, a beautiful marble structure that serves as the final resting place of Pakistan's founder."
  },
  {
    name: "Swat Valley",
    imageUrl: swatValleyImg,
    description: "Known as the 'Switzerland of Pakistan,' this lush valley offers pristine natural beauty with emerald rivers, dense forests, and snow-capped peaks."
  }
];

export default function Places() {
  return (
    <div className="pt-16">
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-[#01411C] mb-4">
              Beautiful Pakistan
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Discover the breathtaking landscapes and iconic landmarks of our homeland
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {places.map((place, index) => (
              <PlaceCard
                key={index}
                name={place.name}
                imageUrl={place.imageUrl}
                description={place.description}
              />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
