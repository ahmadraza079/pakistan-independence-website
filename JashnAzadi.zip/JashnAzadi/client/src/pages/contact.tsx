import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { Send, CheckCircle } from "lucide-react";

const greetingFormSchema = z.object({
  senderName: z.string().min(2, "Name must be at least 2 characters"),
  senderEmail: z.string().email("Please enter a valid email address"),
  recipientEmail: z.string().email("Please enter a valid recipient email address"),
  greetingMessage: z.string().min(10, "Message must be at least 10 characters"),
});

type GreetingFormData = z.infer<typeof greetingFormSchema>;

export default function Contact() {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { toast } = useToast();

  const form = useForm<GreetingFormData>({
    resolver: zodResolver(greetingFormSchema),
    defaultValues: {
      senderName: "",
      senderEmail: "",
      recipientEmail: "",
      greetingMessage: "",
    },
  });

  const onSubmit = async (data: GreetingFormData) => {
    try {
      // Here you would integrate with EmailJS or your backend API
      // For now, we'll simulate success
      console.log("Greeting form data:", data);
      
      setIsSubmitted(true);
      form.reset();
      
      toast({
        title: "Greetings Sent Successfully! 🇵🇰",
        description: "Your Independence Day wishes have been delivered.",
      });

      // Hide success message after 5 seconds
      setTimeout(() => {
        setIsSubmitted(false);
      }, 5000);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send greetings. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="pt-16">
      <section className="py-20 patriotic-gradient">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Send Independence Day Wishes
            </h1>
            <p className="text-xl text-white opacity-90 max-w-3xl mx-auto">
              Share your patriotic greetings and Independence Day wishes with fellow Pakistanis
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            <Card className="bg-white bg-opacity-10 backdrop-blur-sm border-white border-opacity-30">
              <CardContent className="p-8 md:p-12">
                {isSubmitted ? (
                  <div className="text-center py-8">
                    <CheckCircle className="h-16 w-16 text-green-400 mx-auto mb-4" />
                    <h3 className="text-2xl font-bold text-white mb-2">
                      Greetings Sent Successfully! 🇵🇰
                    </h3>
                    <p className="text-white opacity-90">
                      Your Independence Day wishes have been delivered.
                    </p>
                  </div>
                ) : (
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <div className="grid md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="senderName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-white font-semibold">Your Name</FormLabel>
                              <FormControl>
                                <Input
                                  {...field}
                                  placeholder="Enter your name"
                                  className="bg-white bg-opacity-20 border-white border-opacity-30 text-white placeholder:text-white placeholder:opacity-70 focus:ring-[#FFD700] focus:border-[#FFD700]"
                                />
                              </FormControl>
                              <FormMessage className="text-red-300" />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="senderEmail"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-white font-semibold">Your Email</FormLabel>
                              <FormControl>
                                <Input
                                  {...field}
                                  type="email"
                                  placeholder="your.email@example.com"
                                  className="bg-white bg-opacity-20 border-white border-opacity-30 text-white placeholder:text-white placeholder:opacity-70 focus:ring-[#FFD700] focus:border-[#FFD700]"
                                />
                              </FormControl>
                              <FormMessage className="text-red-300" />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="recipientEmail"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white font-semibold">Recipient's Email</FormLabel>
                            <FormControl>
                              <Input
                                {...field}
                                type="email"
                                placeholder="recipient@example.com"
                                className="bg-white bg-opacity-20 border-white border-opacity-30 text-white placeholder:text-white placeholder:opacity-70 focus:ring-[#FFD700] focus:border-[#FFD700]"
                              />
                            </FormControl>
                            <FormMessage className="text-red-300" />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="greetingMessage"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white font-semibold">Your Independence Day Wishes</FormLabel>
                            <FormControl>
                              <Textarea
                                {...field}
                                rows={6}
                                placeholder="Share your heartfelt Independence Day wishes for Pakistan..."
                                className="bg-white bg-opacity-20 border-white border-opacity-30 text-white placeholder:text-white placeholder:opacity-70 focus:ring-[#FFD700] focus:border-[#FFD700] resize-none"
                              />
                            </FormControl>
                            <FormMessage className="text-red-300" />
                          </FormItem>
                        )}
                      />
                      
                      <div className="text-center">
                        <Button
                          type="submit"
                          className="bg-[#FFD700] hover:bg-yellow-500 text-[#01411C] font-bold py-4 px-8 transform hover:scale-105 transition-all duration-300 shadow-lg"
                          disabled={form.formState.isSubmitting}
                        >
                          <Send className="mr-2 h-4 w-4" />
                          Send Independence Day Greetings
                        </Button>
                      </div>
                    </form>
                  </Form>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
