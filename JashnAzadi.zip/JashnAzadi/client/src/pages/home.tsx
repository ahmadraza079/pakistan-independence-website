import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Moon, Star, ArrowRight } from "lucide-react";

export default function Home() {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="min-h-screen relative overflow-hidden flex items-center justify-center" style={{
        background: 'linear-gradient(135deg, #01411C 0%, #228B22 25%, #01411C 50%, #2E8B57 75%, #01411C 100%)'
      }}>
        {/* Animated background pattern */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0" style={{
            backgroundImage: `radial-gradient(circle at 20% 30%, rgba(255, 215, 0, 0.3) 2px, transparent 2px),
                             radial-gradient(circle at 70% 60%, rgba(255, 215, 0, 0.2) 1px, transparent 1px),
                             radial-gradient(circle at 40% 80%, rgba(255, 255, 255, 0.1) 1px, transparent 1px)`,
            backgroundSize: '60px 60px, 40px 40px, 80px 80px'
          }}></div>
        </div>
        
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="mb-8">
            {/* Enhanced Pakistan flag representation */}
            <div className="w-40 h-24 mx-auto mb-6 relative bg-[#01411C] rounded-xl shadow-2xl border-4 border-[#FFD700] transform hover:scale-110 transition-transform duration-300">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="flex items-center space-x-3 text-[#FFD700]">
                  <Moon className="h-8 w-8 transform -rotate-45 drop-shadow-lg" />
                  <Star className="h-6 w-6 drop-shadow-lg" />
                </div>
              </div>
              {/* Flag shine effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-20 transform -skew-x-12 animate-pulse"></div>
            </div>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 drop-shadow-2xl">
            <span className="bg-gradient-to-r from-white via-[#FFD700] to-white bg-clip-text text-transparent">
              Happy Independence Day 🇵🇰
            </span>
          </h1>
          <p className="text-xl md:text-2xl text-[#FFD700] mb-8 font-semibold drop-shadow-lg">
            Celebrating 77 Years of Freedom & Pride
          </p>
          
          <div className="bg-gradient-to-br from-white/20 to-white/5 backdrop-blur-md rounded-3xl p-8 max-w-4xl mx-auto border border-white/30 shadow-2xl">
            <h2 className="text-3xl font-bold mb-6">
              <span className="bg-gradient-to-r from-[#FFD700] to-yellow-300 bg-clip-text text-transparent drop-shadow-lg">
                Journey to Independence
              </span>
            </h2>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center p-4 rounded-xl bg-white/10 border border-[#FFD700]/30 hover:bg-white/20 transition-all duration-300">
                <div className="text-4xl font-bold bg-gradient-to-r from-[#FFD700] to-yellow-300 bg-clip-text text-transparent mb-2">1857</div>
                <p className="text-white font-medium">War of Independence begins</p>
              </div>
              <div className="text-center p-4 rounded-xl bg-white/10 border border-[#FFD700]/30 hover:bg-white/20 transition-all duration-300">
                <div className="text-4xl font-bold bg-gradient-to-r from-[#FFD700] to-yellow-300 bg-clip-text text-transparent mb-2">1940</div>
                <p className="text-white font-medium">Lahore Resolution passed</p>
              </div>
              <div className="text-center p-4 rounded-xl bg-white/10 border border-[#FFD700]/30 hover:bg-white/20 transition-all duration-300">
                <div className="text-4xl font-bold bg-gradient-to-r from-[#FFD700] to-yellow-300 bg-clip-text text-transparent mb-2">1947</div>
                <p className="text-white font-medium">Pakistan gains independence</p>
              </div>
            </div>
            
            <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/heroes">
                <Button className="bg-gradient-to-r from-[#FFD700] to-yellow-400 hover:from-yellow-400 hover:to-[#FFD700] text-[#01411C] font-bold py-3 px-6 transform hover:scale-105 transition-all duration-300 shadow-xl border-2 border-transparent hover:border-white">
                  Meet Our Heroes
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Link href="/places">
                <Button variant="outline" className="border-2 border-[#FFD700] text-[#FFD700] bg-transparent hover:bg-[#FFD700] hover:text-[#01411C] font-bold py-3 px-6 transform hover:scale-105 transition-all duration-300 shadow-xl">
                  Explore Pakistan
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
